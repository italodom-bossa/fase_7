def calcular_area_retangulo(largura, comprimento):
    return largura * comprimento