def converter_para_hectares(area_m2):
    hectares = area_m2 / 10000
    return hectares