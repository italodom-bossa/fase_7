def calcular_area_circulo(radio):
    pi = 3.141592653589793
    return pi * (radio ** 2)