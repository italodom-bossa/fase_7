from p1.funcoes.database.ler_database import ler_database

# Inicializa o banco de dados carregando os dados do arquivo
banco_de_dados_culturas = ler_database()
